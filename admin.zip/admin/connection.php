<?php
$con = mysql_connect('localhost','mylearni_plan','123456');
$select_db = mysql_select_db("mylearni_planet", $con);
?>